'use strict';
// Node tests for the core logic (the same file the browser uses). Run: npm test
const PizZip = require('pizzip');
const XLSX = require('xlsx');
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const MM = require('../js/mailmerge.js');

const W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"';
const run = (t, color, extra = '') => `<w:r><w:rPr>${color ? `<w:color w:val="${color}"/>` : ''}${extra}</w:rPr><w:t xml:space="preserve">${t}</w:t></w:r>`;
const body = `
<w:p>${run('Dear ')}${run('&lt;&lt;', '000000')}${run('na', 'FFA500', '<w:b/>')}${run('me', 'FFA500', '<w:b/>')}${run('&gt;&gt;', '000000')}${run(', welcome.')}</w:p>
<w:p>${run('Role: ')}${run('&lt;&lt;', '000000')}${run('designation', '0000FF')}${run('&gt;&gt;', '000000')}${run(' here')}</w:p>
<w:p><w:pPr><w:jc w:val="center"/></w:pPr>${run('Joined &lt;&lt; Date-Of Joining &gt;&gt;.', 'AA0000')}</w:p>
<w:tbl><w:tblPr/><w:tblGrid><w:gridCol w:w="4000"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:tcW w:w="4000" w:type="dxa"/></w:tcPr><w:p>${run('&lt;&lt; ', '000000')}${run('address', 'FF0000')}${run(' &gt;&gt;', '000000')}</w:p></w:tc></w:tr></w:tbl>
<w:p>${run('Missing: [&lt;&lt;nocolumn&gt;&gt;]')}</w:p>
<w:sectPr><w:pgSz w:w="12240" w:h="15840"/></w:sectPr>`;
function makeDocx() {
  const z = new PizZip();
  z.file('[Content_Types].xml', '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>');
  z.file('_rels/.rels', '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>');
  z.file('word/_rels/document.xml.rels', '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>');
  z.file('word/styles.xml', `<?xml version="1.0"?><w:styles ${W}><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style></w:styles>`);
  z.file('word/document.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document ${W}><w:body>${body}</w:body></w:document>`);
  return z.generate({ type: 'nodebuffer' });
}
function makeXlsx() {
  const ws = XLSX.utils.aoa_to_sheet([['NAME', 'Designation', 'date of-joining', 'Address', 'Unused'], ['Alice', 'Engineer', '1 Jan 2020', '1 Main St', 'x'], ['Bob', '', '2 Feb 2021', '', 'y'], ['Carol', 'Manager', '3 Mar 2022', '3 Elm Rd', 'z']]);
  const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  return XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
}
let passed = 0, failed = 0;
const t = (name, fn) => { try { fn(); passed++; console.log('  PASS', name); } catch (e) { failed++; console.log('  FAIL', name, '\n      ', e.message); } };
const xml = (buf) => new PizZip(buf).file('word/document.xml').asText();
const plain = (x) => x.replace(/<w:br w:type="page"\/>/g, '\f').replace(/<\/w:p>/g, '\n').replace(/<[^>]+>/g, '');

const docx = makeDocx(), xlsx = makeXlsx();
const ph = MM.detectPlaceholders(docx), wb = MM.readWorkbook(xlsx), keys = ph.map((p) => p.key);
const gen = (mode, ov) => xml(MM.mergeDocx(docx, MM.buildRecords(wb.records, keys, ov || {}, mode)));

console.log('Detection and mapping');
t('detects split / spaced / table placeholders', () => assert.deepStrictEqual(keys.slice().sort(), ['address', 'dateofjoining', 'designation', 'name', 'nocolumn']));
t('maps headers case-insensitively, reports missing/unused', () => {
  const a = MM.analyze(ph, wb);
  assert.strictEqual(a.mapping.find((m) => m.key === 'dateofjoining').column, 'date of-joining');
  assert.deepStrictEqual(a.missingColumns, ['nocolumn']); assert.deepStrictEqual(a.unusedColumns, ['Unused']);
  assert.strictEqual(wb.records.length, 3);
});
console.log('Replace mode');
let x = gen('replace'), p = plain(x);
t('3 records, 2 page breaks, spacing preserved', () => {
  assert.strictEqual((x.match(/w:type="page"/g) || []).length, 2);
  for (const s of ['Dear Alice, welcome.', 'Role: Engineer here', 'Joined 1 Jan 2020.', 'Missing: []']) assert.ok(p.includes(s), s);
});
t('value inherits field-name formatting, not bracket colour', () => {
  assert.ok(/<w:b\/><\/w:rPr><w:t xml:space="preserve">Alice/.test(x));
  assert.ok(/<w:color w:val="0000FF"\/><\/w:rPr><w:t xml:space="preserve">Engineer<\/w:t>/.test(x));
  assert.ok(/<w:color w:val="FF0000"\/><\/w:rPr><w:t xml:space="preserve">1 Main St<\/w:t>/.test(x));
});
t('blank cell stays blank; sectPr kept last', () => { assert.ok(p.includes('Role:  here')); assert.ok(/<w:sectPr>.*<\/w:sectPr><\/w:body>/.test(x)); });
t('website value overrides every record; blank input falls back', () => {
  const o = plain(gen('replace', { designation: 'CEO' }));
  assert.strictEqual((o.match(/Role: CEO here/g) || []).length, 3); assert.ok(o.includes('Dear Bob'));
});
t('intentionally blank override beats Excel', () => assert.strictEqual((plain(gen('replace', { designation: '' })).match(/Role:  here/g) || []).length, 3));
console.log('Append mode');
t('3 originals unchanged + 1 extra from website values only', () => {
  const pages = plain(gen('append', { name: 'Zed', designation: 'Intern' })).split('\f');
  assert.strictEqual(pages.length, 4);
  assert.ok(pages[0].includes('Dear Alice') && pages[2].includes('Role: Manager here'));
  assert.ok(pages[3].includes('Dear Zed, welcome.') && pages[3].includes('Role: Intern here') && !pages[3].includes('Alice') && pages[3].includes('Joined .'));
});
t('preview plan uses the same rules', () => {
  const r = MM.previewRecords(wb.records, keys, { name: 'Zed' }, 'append', 1);
  assert.strictEqual(r.rowRec.name, 'Bob'); assert.strictEqual(r.extraRec.name, 'Zed'); assert.strictEqual(r.extraRec.designation, ''); assert.strictEqual(r.rowNumber, 2);
  assert.strictEqual(MM.previewRecords(wb.records, keys, { name: 'Zed' }, 'replace', 1).rowRec.name, 'Zed');
});
console.log('Validation and preview prep');
t('corrupt docx / empty workbook give user errors', () => {
  assert.throws(() => MM.detectPlaceholders(Buffer.from('PK' + 'x'.repeat(60))), (e) => e.user);
  const w = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(w, XLSX.utils.aoa_to_sheet([]), 'S');
  assert.throws(() => MM.readWorkbook(XLSX.write(w, { type: 'buffer', bookType: 'xlsx' })), (e) => e.user && /empty/.test(e.message));
});
t('prepareForPreview adds colour/alignment styles', () => {
  const r = MM.prepareForPreview(MM.mergeDocx(docx, [wb.records[0]]));
  assert.ok(r.styleMap.some((s) => s.includes('clr-FFA500')) && r.styleMap.some((s) => s.includes('jc-center')));
});
fs.writeFileSync(path.join(__dirname, 'sample-template.docx'), docx);
fs.writeFileSync(path.join(__dirname, 'sample-data.xlsx'), xlsx);
console.log(`\n${passed} passed, ${failed} failed`); process.exit(failed ? 1 : 0);
